    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Table Penjualan</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="table-1">
                        <thead>
                            <tr>
                                <th>
                                    Tanggal
                                </th>
                                <th>Pembeli</th>
                                <th>Satuan</th>
                                <th>Kelas</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Total</th>
                                <th>Dibayar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            $result = mysqli_query($conn, "
                            SELECT 
                                penjualan.id as id, 
                                date(penjualan.tanggal) as tanggal,
                                penjualan.nama_customer as customer, 
                                satuan.name as satuan, 
                                kelas.kelas as kelas, 
                                harga.harga as harga, 
                                penjualan.jumlah as jumlah,
                                ROUND(satuan.jumlah_butir*harga.harga/30*jumlah ,0) as total, 
                                penjualan.dibayar as dibayar
                            FROM tbl_penjualan as penjualan
                            INNER join tbl_satuan as satuan
                            INNER join tbl_harga as harga
                            INNER join tbl_kelas as kelas
                            where satuan.id=penjualan.satuan_id and harga.id=penjualan.harga_id and kelas.id=penjualan.kelas_id");

                            if (mysqli_num_rows($result) > 0) {
                                // output data of each row
                                while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                                    <tr>
                                        <td><?php echo $row["tanggal"] ?></td>
                                        <td><?php echo $row["customer"] ?></td>
                                        <td><?php echo $row["satuan"] ?></td>
                                        <td><?php echo $row["kelas"] ?></td>
                                        <td><?php echo number_format($row["harga"]) ?></td>
                                        <td><?php echo $row["jumlah"] ?></td>
                                        <td><?php echo number_format($row["total"]); ?>
                                        </td>
                                        <td><?php

                                            $dibayar = $row["dibayar"];
                                            if ($dibayar == 0) {
                                                echo  '<a onclick=bayar("' . $row["id"] . '") data-toggle="modal" data-target="#exampleModalCenter" class="btn btn-danger">Belum bayar</a>';
                                            } else {

                                                echo  '<a class="btn btn-success">Sudah bayar</a>';
                                            }
                                            ?>

                                        </td>
                                    </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        var penjualanIdToPay = "";

        function bayar(data) {
            document.getElementById("proccedPaymentId").value = data;
        }
    </script>