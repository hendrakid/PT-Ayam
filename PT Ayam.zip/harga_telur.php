<div class="row">
    <?php include("Forms/form_harga_telur.php"); ?>
    <?php include("Charts/chart_harga_telur.php"); ?>
</div>
<div class="row">
    <?php include("Tables/tabel_harga_telur.php"); ?>
</div>