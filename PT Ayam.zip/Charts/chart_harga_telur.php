<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"></script>
<?php
$year = date("Y");

$hargaSuper     = mysqli_query($conn, "SELECT AVG(harga) as harga, MONTHNAME(tanggal) as bulan FROM tbl_harga where kelas_id='id4' and YEAR(tanggal)=$year group by MONTH(tanggal) order by tanggal");
$hargaStandar   = mysqli_query($conn, "SELECT AVG(harga) as harga, MONTHNAME(tanggal) as bulan FROM tbl_harga where kelas_id='id3' and YEAR(tanggal)=$year group by MONTH(tanggal) order by tanggal");
$hargaMK        = mysqli_query($conn, "SELECT AVG(harga) as harga, MONTHNAME(tanggal) as bulan FROM tbl_harga where kelas_id='id2' and YEAR(tanggal)=$year group by MONTH(tanggal) order by tanggal");
$hargaBakso     = mysqli_query($conn, "SELECT AVG(harga) as harga, MONTHNAME(tanggal) as bulan FROM tbl_harga where kelas_id='id1' and YEAR(tanggal)=$year group by MONTH(tanggal) order by tanggal");
$bulan          = mysqli_query($conn, "SELECT MONTHNAME(tanggal) as bulan FROM tbl_harga group by MONTH(tanggal) order by tanggal");

?>

<div class="col-12 col-md-6 col-lg-6">
    <div class="card">
        <div class="card-header">
            <h4>Chart Harga Telur</h4>
        </div>
        <div class="card-body">
            <canvas id="hargaTelurChart"></canvas>
        </div>
    </div>
</div>
<?php

while ($b = mysqli_fetch_array($hargaSuper)) {
    $hargaSuperArray[] = $b['bulan'] . "|" . $b['harga'];
}
while ($b = mysqli_fetch_array($hargaStandar)) {
    $hargaStandarArray[] = $b['bulan'] . "|" . $b['harga'];
}
while ($b = mysqli_fetch_array($hargaMK)) {
    $hargaMKArray[] = $b['bulan'] . "|" . $b['harga'];
}
while ($b = mysqli_fetch_array($hargaBakso)) {
    $hargaBaksoArray[] = $b['bulan'] . "|" . $b['harga'];
}
?>

<script>
    console.log((new Date()).getFullYear());

    function masking(months, data) {
        var maskedData = [];
        var latestValue;
        var monthNow = (new Date()).getMonth();

        months.forEach((month, index) => {
            var yy = data.find(element => element.split("|")[0] == month);
            if (yy !== undefined) {
                maskedData.push(parseInt(yy.split("|")[1]));
                latestValue = parseInt(yy.split("|")[1]);
            } else {
                if (index <= monthNow)
                    maskedData.push(latestValue);
                else
                    maskedData.push(0);
            }

        });
        return maskedData;
    }

    const kelas = ["Super", "Standar", "MK", "Bakso"];
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    var dataSuper = masking(months, <?php echo json_encode($hargaSuperArray) ?>);
    var dataStandar = masking(months, <?php echo json_encode($hargaStandarArray) ?>);
    var dataMK = masking(months, <?php echo json_encode($hargaMKArray) ?>);
    var dataBakso = masking(months, <?php echo json_encode($hargaBaksoArray) ?>);
    console.log(dataSuper);

    var ctx = document.getElementById("hargaTelurChart");
    if (ctx) {
        ctx.height = 150;
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: "Super",
                    borderColor: "rgba(0,0,0,.5)",
                    borderWidth: "1.5",
                    backgroundColor: "rgba(255,0,255,.3)",
                    data: dataSuper
                }, {
                    label: "Standar",
                    borderColor: "rgba(0,0,0,.5)",
                    borderWidth: "1.5",
                    backgroundColor: "rgba(0,255,0,.3)",
                    data: dataStandar
                }, {
                    label: "MK",
                    borderColor: "rgba(0,0,0,.5)",
                    borderWidth: "1.5",
                    backgroundColor: "rgba(0,0,255,.3)",
                    data: dataMK
                }, {
                    label: "Bakso",
                    borderColor: "rgba(0,0,0,.5)",
                    borderWidth: "1.5",
                    backgroundColor: "rgba(0, 255, 255, 0.3)",
                    data: dataBakso
                }]
            },
            options: {
                legend: {
                    position: 'top',
                    labels: {}

                },
                responsive: true,
                tooltips: {
                    mode: 'index',
                    intersect: false
                },
                hover: {
                    mode: 'nearest',
                    intersect: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            fontColor: "#9aa0ac", // Font Color
                        }
                    }],
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontColor: "#9aa0ac", // Font Color
                        }
                    }]
                }

            }
        });
    }
</script>