<div class="col-12 col-md-6 col-lg-6">
    <form method="post" name="form_penjualan" enctype="multipart/form-data" action="actionForm/save_form_penjualan.php">
        <div class="card">
            <div class="card-header">
                <h4>Form Penjualan</h4>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label>Nama Pembeli</label>
                    <div class="input-group">
                        <input type="text" name="nama_pembeli" class="form-control">
                    </div>
                    <label>Kelas</label>
                    <select class="form-control" id="kelas_id" name="kelas_id" onchange="showHargaHariIniAndTotal(this)">

                        <option value="Pilih Kelas">Pilih Kelas</option>
                        <?php

                        $sql = "SELECT id, kelas FROM tbl_kelas";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            // output data of each row
                            while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                                <option value="<?php echo $row["id"] ?>"><?php echo $row["kelas"] ?></option>
                        <?php
                            }
                        }
                        ?>
                    </select>
                    <label class="form-label">Button Input</label>
                    <div class="selectgroup w-100">
                        <label class="selectgroup-item">
                            <input type="radio" name="satuan_id" value="id1" class="selectgroup-input-radio" checked>
                            <span class="selectgroup-button">Ikat</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="radio" name="satuan_id" value="id2" class="selectgroup-input-radio">
                            <span class="selectgroup-button">Papan</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="radio" name="satuan_id" value="id3" class="selectgroup-input-radio">
                            <span class="selectgroup-button">Butir</span>
                        </label>
                    </div>
                    <label>Jumlah</label>
                    <div class="input-group">
                        <input type="number" id="jumlah" name="jumlah" class="form-control" onkeyup="showTotalAndHargaHariIni(this)">
                    </div>

                    <input hidden type="text" id="harga_id" name="harga_id" class="form-control">

                    <label>Harga Hari Ini</label>
                    <div class="input-group">
                        <input disabled type="text" id="harga" class="form-control">
                    </div>
                    <label>Total Penjualan</label>
                    <div class="input-group">
                        <input disabled type="text" id="total" class="form-control">
                    </div>

                    <div class="input-group">
                        <label class="custom-switch mt-3">
                            <input type="checkbox" name="dibayar" class="custom-switch-input">
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description">Sudah dibayar</span>
                        </label>
                    </div>
                </div>
                <div class=" buttons">
                    <input class="btn btn-primary" type="submit" name="save" value="Simpan">
                </div>
            </div>
        </div>
    </form>
</div>

<?php
$hargaHariIni = mysqli_query($conn, "SELECT a.id, a.harga, a.kelas_id FROM tbl_harga as a, (SELECT harga, kelas_id, MAX(tanggal) as tanggal FROM tbl_harga group by kelas_id) as b where a.tanggal=b.tanggal and a.kelas_id=b.kelas_id");

while ($b = mysqli_fetch_array($hargaHariIni)) {
    $hargaArray[] = $b['kelas_id'] . "|" . $b['harga'] . "|" . $b['id'];
}
?>

<script type="text/javascript">
    var hargaHarIni = <?php echo json_encode($hargaArray) ?>;

    function showHargaHariIniAndTotal(item) {
        var hargaOnKelas = hargaHarIni.find(element => element.split("|")[0] == item.value);


        document.getElementById("harga_id").value = hargaOnKelas.split("|")[2];


        document.getElementById("harga").value = (hargaOnKelas.split("|")[1]).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("total").value = (hargaOnKelas.split("|")[1] * document.getElementById("jumlah").value).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return;
    }

    function showTotalAndHargaHariIni(item) {
        var kelasId = document.getElementById("kelas_id").value;
        var hargaOnKelas = hargaHarIni.find(element => element.split("|")[0] == kelasId);
        document.getElementById("harga").value = (hargaOnKelas.split("|")[1]).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("total").value = (hargaOnKelas.split("|")[1] * item.value).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return;
    }
</script>