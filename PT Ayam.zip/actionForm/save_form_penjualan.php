<?php
include_once '../connection.php';
if (isset($_POST['save'])) {
	$nama_pembeli = $_POST['nama_pembeli'];
	$kelas_id = $_POST['kelas_id'];
	$satuan_id = $_POST['satuan_id'];
	$jumlah = $_POST['jumlah'];
	$dibayar = $_POST['dibayar'];
	$harga_id = $_POST['harga_id'];
	$id = uniqid();
	if ($dibayar === 'on') $dibayar = 1;
	else $dibayar = 0;

	echo $nama_pembeli . '<br/>';
	echo $kelas_id . '<br/>';
	echo $satuan_id . '<br/>';
	echo $jumlah . '<br/>';
	echo $dibayar . '<br/>';
	echo $harga_id . '<br/>';

	$sql = "INSERT INTO tbl_penjualan (id,kelas_id,satuan_id,harga_id,nama_customer,jumlah,dibayar)
	 VALUES ('$id','$kelas_id','$satuan_id','$harga_id','$nama_pembeli','$jumlah','$dibayar')";
	echo $sql;

	if (mysqli_query($conn, $sql)) {
		// echo "New record created successfully !";
		header("location:../index.php?page=all");
	} else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	}
	mysqli_close($conn);
}
