<?php
include_once '../connection.php';
if (isset($_POST['save'])) {
	$super = $_POST['super'];
	$standar = $_POST['standar'];
	$mk = $_POST['mk'];
	$bakso = $_POST['bakso'];
	$id = uniqid();
	$sql = "INSERT INTO tbl_hasil (id,super,standar,mk,bakso)
	 VALUES ('$id','$super','$standar','$mk','$bakso')";
	if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
		header("location:../index.php?page=all");
	} else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	}
	mysqli_close($conn);
}
