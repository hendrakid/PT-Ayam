<?php
include_once '../connection.php';
if(isset($_POST['save']))
{	 
	 $kelas_id = $_POST['kelas_id'];
	 $harga = str_replace(',', '', $_POST['harga']);
     $id= uniqid();
	 $sql = "INSERT INTO tbl_harga (id,kelas_id,harga)
	 VALUES ('$id','$kelas_id','$harga')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
        header("location:../index.php?page=all");
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
