<div class="row">
    <?php include("Forms/form_penjualan.php"); ?>
    <?php include("Charts/chart_penjualan.php"); ?>
</div>
<div class="row">
    <?php include("Tables/tabel_penjualan.php"); ?>
</div>