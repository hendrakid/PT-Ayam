<div class="row">
    <?php include("Forms/form_hasil_telur.php"); ?>
    <?php include("Charts/chart_hasil_telur.php"); ?>
</div>
<div class="row">
    <?php include("Tables/tabel_hasil_telur.php"); ?>
</div>